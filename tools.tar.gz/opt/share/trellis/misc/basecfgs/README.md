# Skeleton Configuration Files

These contain unknown bits that should always be included in a 
bitstream for each architecture.

